<?php

/**
 * PHP Exception used in the ImageResize class
 */
