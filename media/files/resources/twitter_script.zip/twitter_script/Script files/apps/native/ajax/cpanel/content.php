<?php 
# @*************************************************************************@
# @ @author Mansur Altamirov (Mansur_TL)									@
# @ @author_url 1: https://www.instagram.com/mansur_tl                      @
# @ @author_url 2: http://codecanyon.net/user/mansur_tl                     @
# @ @author_email: highexpresstore@gmail.com                                @
# @*************************************************************************@
# @ ColibriSM - The Ultimate Modern Social Media Sharing Platform           @
# @ Copyright (c) 21.03.2020 ColibriSM. All rights reserved.                @
# @*************************************************************************@

if (empty($cl['is_admin'])) {
	$data['status'] = 400;
    $data['error']  = 'Invalid access token';
}

else if ($action == 'save_settings') {	
	$data['status']    = 400;
	$data['err_field'] = null;
	$raw_configs       = $db->get(T_CONFIGS);
	$raw_configs       = ((cl_queryset($raw_configs)) ? $raw_configs : array());

	if ($raw_configs) {

		require_once(cl_full_path("core/apps/cpanel/settings/app_ctrl.php"));

		foreach ($raw_configs as $config_data) {
			if (isset($_POST[$config_data['name']])) {

				if ($config_data['name'] == 'google_analytics') {
					$conf_new_val = htmlspecialchars($_POST[$config_data['name']]);
				}

				else {
					$conf_new_val = cl_text_secure($_POST[$config_data['name']]);
				}

				if ($config_data['regex']) {
					if (preg_match($config_data['regex'], $conf_new_val)) {
						cl_admin_save_config($config_data['name'], $conf_new_val);
					}

					else {
						$field_label       = $config_data['title'];
						$data['message']   = cl_translate('Invalid value of field: {@field_name@}', array('field_name' => $field_label));
						$data['err_field'] = $config_data['name']; break;
					}
				}
				else {
					cl_admin_save_config($config_data['name'],$conf_new_val);
				}
			}
		}

		if (empty($data['err_field'])) {
			$data['status'] = 200;
		}
	}
}

else if ($action == 'get_users') {

	require_once(cl_full_path("core/apps/cpanel/users/app_ctrl.php"));

	$offset_to        = fetch_or_get($_GET['dir'], 'none');
	$offset_lt        = ((is_posnum($_GET['offset_lt'])) ? intval($_GET['offset_lt']) : 0);
	$offset_gt        = ((is_posnum($_GET['offset_gt'])) ? intval($_GET['offset_gt']) : 0);
	$users            = array();
	$data['status']   = 404;
	$data['err_code'] = 0;
	$html_arr         = array();

	if ($offset_to == 'up' && $offset_lt) {
		$users          = cl_admin_get_users(array(
			'limit'     => 10,
			'offset'    => $offset_lt,
			'offset_to' => 'gt',
			'order'     => 'ASC'
		));

		$users = array_reverse($users);
	}

	else if($offset_to == 'down' && $offset_gt) {
		$users          = cl_admin_get_users(array(
			'limit'     => 10,
			'offset'    => $offset_gt,
			'offset_to' => 'lt',
			'order'     => 'DESC'
		));
	}

	if (not_empty($users)) {
		foreach ($users as $cl['li']) {
			array_push($html_arr, cl_template('cpanel/assets/users/includes/list_item'));
		}

		$data['status'] = 200;
		$data['html']   = implode('', $html_arr);
	}
}

else if ($action == 'get_posts') {

	require_once(cl_full_path("core/apps/cpanel/posts/app_ctrl.php"));

	$offset_to        = fetch_or_get($_GET['dir'], 'none');
	$offset_lt        = ((is_posnum($_GET['offset_lt'])) ? intval($_GET['offset_lt']) : 0);
	$offset_gt        = ((is_posnum($_GET['offset_gt'])) ? intval($_GET['offset_gt']) : 0);
	$posts            = array();
	$data['status']   = 404;
	$data['err_code'] = 0;
	$html_arr         = array();

	if ($offset_to == 'up' && $offset_lt) {
		$posts          = cl_admin_get_posts(array(
			'limit'     => 10,
			'offset'    => $offset_lt,
			'offset_to' => 'gt',
			'order'     => 'ASC'
		));

		$posts = array_reverse($posts);
	}

	else if($offset_to == 'down' && $offset_gt) {
		$posts          = cl_admin_get_posts(array(
			'limit'     => 10,
			'offset'    => $offset_gt,
			'offset_to' => 'lt',
			'order'     => 'DESC'
		));
	}

	if (not_empty($posts)) {
		foreach ($posts as $cl['li']) {
			array_push($html_arr, cl_template('cpanel/assets/publications/includes/list_item'));
		}

		$data['status'] = 200;
		$data['html']   = implode('', $html_arr);
	}
}

else if($action == 'delete_user') {
	$data['status']   = 404;
	$data['err_code'] = 0;
	$user_id          = fetch_or_get($_POST['id'], 0);

	if (is_posnum($user_id)) {
		$data['status']      = 200;
		$data['status_code'] = (cl_delete_user_data($user_id) == true) ? 1 : 0;
	}
}

else if($action == 'delete_post') {
    $data['err_code'] = 0;
    $data['status']   = 400;
    $post_id          = fetch_or_get($_POST['id'], 0);

    if (is_posnum($post_id)) {
        $post_data = cl_raw_post_data($post_id);

        if (not_empty($post_data)) {

            $post_owner = cl_raw_user_data($post_data['user_id']);

            if (not_empty($post_owner)) {
                if ($post_data['target'] == 'publication') {

                    $posts_total = ($post_owner['posts'] -= 1);
                    $posts_total = ((is_posnum($posts_total)) ? $posts_total : 0);

                    cl_update_user_data($post_data['user_id'], array(
                        'posts' => $posts_total
                    ));

                    $db = $db->where('publication_id', $post_id);
                    $qr = $db->delete(T_POSTS);
                }

                else {
                    cl_update_thread_replys($post_data['thread_id'], 'minus');
                }
                
                cl_recursive_delete_post($post_id);
                
                $data['status'] = 200;
            }
        }
    }
}

else if($action =='create_backup') {

	require_once(cl_full_path("core/apps/cpanel/backups/app_ctrl.php"));
	
	require_once(cl_full_path("core/apps/cpanel/settings/app_ctrl.php"));

	$data['err_code'] = 'failed_to_create_backup';
	$data['status']   = 500;
	$new_backup       = cl_admin_create_backup();

	if ($new_backup) {
		$time                = time();
		$data['status']      = 200;
		$data['err_code']    = 0;
		$data['last_backup'] = date('d F, Y - h:m', $time);

		cl_admin_save_config('last_backup', $time);
	}
}