from django.shortcuts import render
from .resources import MyModelResource
from tablib import Dataset

def import_data(request):
    if request.method == 'POST':
        my_model_resource = MyModelResource()
        dataset = Dataset()
        new_data = request.FILES['myfile'].read()
        dataset.load(new_data, format='xlsx')
        result = my_model_resource.import_data(dataset, dry_run=True)  # First dry run to check for errors
        if not result.has_errors():
            my_model_resource.import_data(dataset, dry_run=False)  # Import data for real
            return render(request, 'su.html')
        else:
            errors = result.base_errors
            return render(request, 'base.html', {'errors': errors})
    return render(request, 'import.html')


# # Custom export view
# @staff_member_required
# def export_data(request):
#     my_model_resource = MyModelResource()
#     dataset = my_model_resource.export()
#     response = HttpResponse(dataset.xlsx, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
#     response['Content-Disposition'] = 'attachment; filename="mydata.xlsx"'
#     return response
# views.py
# views.py
# views.py
from django.shortcuts import render
from django.contrib.auth.models import Permission
from django.apps import apps

def admin_site(request):
    registered_models = [
        model for model in apps.get_models() 
        if model != Permission
    ]
    return render(request, 'admin_site.html', {'registered_models': registered_models})
